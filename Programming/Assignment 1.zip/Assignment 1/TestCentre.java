public class TestCentre {
    public String name;
    public String address;

    public TestCentre(String name, String address) {
        this.name = name;
        this.address = address;
    }

    //  Getter Methods for the Test Centre Name and Address
    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }
}
